package ua.edu.sumdu.j2se.mayfet.tasks.model;

public class ListTypes {
    public enum types{ARRAY, LINKED}
}
