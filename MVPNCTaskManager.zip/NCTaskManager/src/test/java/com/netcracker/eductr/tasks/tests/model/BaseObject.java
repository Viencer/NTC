package com.netcracker.eductr.tasks.tests.model;

public abstract class BaseObject {
    protected Object instance;

    public Object getInstance() {
        return instance;
    }
}
